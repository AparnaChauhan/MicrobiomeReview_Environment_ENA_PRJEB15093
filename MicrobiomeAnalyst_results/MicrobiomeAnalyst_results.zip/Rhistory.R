mbSet<-Init.mbSetObj()
mbSet<-SetModuleType(mbSet, "mdp")
mbSet<-ReadSampleTable(mbSet, "Metadata_PRJEB15093_modified_MicrobiomeAnalyst.csv");
mbSet<-Read16SAbundData(mbSet, "otu_table.v1.biom","biom","Greengenes","F");
mbSet<-SanityCheckData(mbSet, "biom");
mbSet<-PlotLibSizeView(mbSet, "norm_libsizes_0","png");
mbSet<-CreatePhyloseqObj(mbSet, "biom","Greengenes","F")
mbSet<-ApplyAbundanceFilter(mbSet, "prevalence", 4, 0.2);
mbSet<-ApplyVarianceFilter(mbSet, "sd", 0.1);
mbSet<-PerformNormalization(mbSet, "none", "none", "clr");
mbSet<-PlotTaxaAundanceBar(mbSet, "taxa_alpha_0","Phylum","sample_description", "null", "barraw",10, "set3","sum",10, "bottom", "F", "png");
mbSet<-PlotTaxaAundanceBar(mbSet, "taxa_alpha_1","Genus","sample_description", "none", "barnorm",5, "set3","sum",10, "bottom", "F", "png");
mbSet<-PlotTaxaAundanceBar(mbSet, "taxa_alpha_2","Genus","sample_description", "none", "barraw",5, "set3","sum",10, "bottom", "F", "png");
mbSet<-PlotOverallPieGraph(mbSet, "Phylum", 10,"sum", 10, "bottom");
GetSeriesColors()
mbSet<-SavePiechartImg(mbSet, "Phylum","primary_piechart_0","png");
mbSet<-PlotOverallPieGraph(mbSet, "Genus", 5,"sum", 10, "bottom");
GetSeriesColors()
mbSet<-SavePiechartImg(mbSet, "Genus","primary_piechart_1","png");
mbSet<-PlotOverallPieGraph(mbSet, "Family", 5,"sum", 10, "bottom");
GetSeriesColors()
mbSet<-SavePiechartImg(mbSet, "Family","primary_piechart_2","png");
mbSet<-PlotRarefactionCurve(mbSet, "filt","sample_description","sample_description","sample_description","5","rarefaction_curve_0","png");
mbSet<-PlotRarefactionCurve(mbSet, "filt","sample_description","sample_description","sample_description","5","rarefaction_curve_1","png");
mbSet<-PrepareHeatTreePlot(mbSet, "sample_description", "Genus", "dbgr", "dft", "Worm burrow_vs_sediment", 0.05, "heat_tree_0","png");
mbSet<-PrepareHeatTreePlot(mbSet, "sample_description", "Species", "dbgr", "dft", "Worm burrow_vs_sediment", 0.05, "heat_tree_1","png");
mbSet<-PrepareHeatTreePlot(mbSet, "sample_description", "Species", "dbgr", "dft", "Worm burrow_vs_blank", 0.05, "heat_tree_2","png");
mbSet<-PrepareHeatTreePlot(mbSet, "sample_description", "Species", "dbgr", "dft", "sediment_vs_blank", 0.05, "heat_tree_3","png");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_0","Chao1","sample_description","OTU", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_0","Chao1","sample_description","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "tt","sample_description");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_1","Chao1","sample_description","OTU", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_1","Chao1","sample_description","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "tt","sample_description");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_2","Chao1","sample_description","OTU", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_2","Chao1","sample_description","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "nonpar","sample_description");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_3","Shannon","sample_description","OTU", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_3","Shannon","sample_description","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "nonpar","sample_description");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_4","Simpson","sample_description","OTU", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_4","Simpson","sample_description","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "nonpar","sample_description");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_5","Simpson","sample_description","OTU", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_5","Simpson","sample_description","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "tt","sample_description");
mbSet<-PlotAlphaData(mbSet, "filt","alpha_diver_6","Shannon","sample_description","OTU", "default", "png");
mbSet<-PlotAlphaBoxData(mbSet, "alpha_diverbox_6","Shannon","sample_description","default", "png");
mbSet<-PerformAlphaDiversityComp(mbSet, "tt","sample_description");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_0",0.2,0.01,"OTU","bwm","overview", "all_samples", "sample_description", "null", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_1",0.2,0.01,"Species","bwm","overview", "all_samples", "sample_description", "blank", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_2",0.2,0.01,"Genus","bwm","overview", "all_samples", "sample_description", "blank", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_3",0.2,0.01,"Family","bwm","overview", "all_samples", "sample_description", "blank", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_4",0.2,0.01,"Family","bwm","overview", "all_samples", "sample_description", "sediment", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_5",0.2,0.01,"Genus","bwm","overview", "all_samples", "sample_description", "sediment", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_6",0.2,0.01,"Genus","bwm","overview", "all_samples", "sample_description", "Worm burrow", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_7",0.2,0.01,"Family","bwm","overview", "all_samples", "sample_description", "Worm burrow", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_8",0.2,0.01,"Family","bwm","overview", "all_samples", "sample_description", "sediment", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_9",0.2,0.01,"OTU","bwm","overview", "all_samples", "sample_description", "sediment", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_10",0.2,0.01,"OTU","bwm","overview", "all_samples", "sample_description", "sediment", "png");
mbSet<-CoreMicrobeAnalysis(mbSet, "core_micro_11",0.2,0.01,"OTU","bwm","overview", "all_samples", "sample_description", "Worm burrow", "png");
mbSet<-PlotHeatmap(mbSet, "heatmap_0","euclidean","ward.D","bwm","sample_description","OTU","overview","F", "png","T","F");
mbSet<-PlotHeatmap(mbSet, "heatmap_1","euclidean","ward.D","bwm","sample_description","OTU","overview","F", "png","T","F");
mbSet<-PlotHeatmap(mbSet, "heatmap_2","euclidean","ward.D","bwm","sample_description","Species","overview","F", "png","T","F");
mbSet<-PlotHeatmap(mbSet, "heatmap_3","euclidean","ward.D","bwm","sample_description","Genus","overview","F", "png","T","F");
mbSet<-PlotHeatmap(mbSet, "heatmap_4","euclidean","ward.D","bwm","sample_description","Family","overview","F", "png","T","F");
mbSet<-PlotTreeGraph(mbSet, "plot_tree_0","bray","ward.D","sample_description","OTU", "default", "png");
mbSet<-PlotTreeGraph(mbSet, "plot_tree_1","jaccard","ward.D","sample_description","Genus", "default", "png");
mbSet<-PlotTreeGraph(mbSet, "plot_tree_2","jsd","ward.D","sample_description","Genus", "default", "png");
mbSet<-PrepareCorrExpValues(mbSet, "sample_description", "Genus", "dbgr", "dft", "all", "0.05")
mbSet<-PerformNetworkCorrelation(mbSet,"Genus", "sparcc", "expr",100, 0.05, 0.3, "mean", "cor_net_0.json")
mbSet<-PrepareCorrExpValues(mbSet, "sample_description", "Species", "dbgr", "dft", "all", "0.05")
mbSet<-PerformNetworkCorrelation(mbSet,"Species", "sparcc", "expr",100, 0.05, 0.3, "mean", "cor_net_1.json")
group.vec <- c("Worm burrow","sediment")
mbSet<-SetGroupItems(mbSet, group.vec);
mbSet<-PrepareCorrExpValues(mbSet, "sample_description", "Species", "dbgr", "dft", "groups", "0.05")
mbSet<-PerformNetworkCorrelation(mbSet,"Species", "sparcc", "expr",100, 0.05, 0.3, "mean", "cor_net_2.json")
mbSet<-Match.Pattern(mbSet, "pearson", "1-2-3", "Genus", "sample_description")
mbSet<-PlotCorr(mbSet, "ptn_0", "png", width=NA)
mbSet<-Match.Pattern(mbSet, "spearman", "1-2-3", "Genus", "sample_description")
mbSet<-PlotCorr(mbSet, "ptn_1", "png", width=NA)
mbSet<-Match.Pattern(mbSet, "kendall", "1-2-3", "Genus", "sample_description")
mbSet<-PlotCorr(mbSet, "ptn_2", "png", width=NA)
mbSet<-Match.Pattern(mbSet, "kendall", "3-2-1", "Genus", "sample_description")
mbSet<-PlotCorr(mbSet, "ptn_3", "png", width=NA)
mbSet<-PerformUnivarTest(mbSet, "sample_description",0.05,"NA","OTU","tt");
mbSet<-PerformUnivarTest(mbSet, "sample_description",0.05,"NA","Genus","tt");
mbSet<-PerformUnivarTest(mbSet, "sample_description",0.05,"NA","Genus","nonpar");
mbSet<-PerformUnivarTest(mbSet, "sample_description",0.05,"NA","Species","nonpar");
mbSet<-PerformUnivarTest(mbSet, "sample_description",0.05,"NA","OTU","nonpar");
mbSet<-PerformUnivarTest(mbSet, "sample_description",0.05,"NA","OTU","tt");
mbSet<-PerformMetagenomeSeqAnal(mbSet, "sample_description",0.05,"NA","OTU","zigfit");
mbSet<-PerformMetagenomeSeqAnal(mbSet, "sample_description",0.05,"NA","Genus","ffm");
mbSet<-PerformMetagenomeSeqAnal(mbSet, "sample_description",0.05,"NA","Genus","zigfit");
mbSet<-PerformRNAseqDE(mbSet, "EdgeR",0.05,"sample_description","NA","OTU");
mbSet<-PerformRNAseqDE(mbSet, "EdgeR",0.05,"sample_description","NA","Genus");
mbSet<-PerformRNAseqDE(mbSet, "DESeq2",0.05,"sample_description","NA","Genus");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 2.0,  "sample_description","F","NA","OTU");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_0","png");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 2.0,  "sample_description","F","NA","Genus");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_1","png");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 1.0,  "sample_description","F","NA","Genus");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_2","png");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 1.0,  "sample_description","F","NA","OTU");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_3","png");
mbSet<-PerformLefseAnal(mbSet,  0.1, "fdr", 1.0,  "sample_description","F","NA","Family");
mbSet<-PlotLEfSeSummary(mbSet, 15, "dot",  "bar_graph_4","png");
mbSet<-RF.Anal(mbSet, 500,7,1,"sample_description","OTU")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_0","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_0","png", width=NA)
mbSet<-RF.Anal(mbSet, 500,7,1,"sample_description","Genus")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_1","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_1","png", width=NA)
mbSet<-RF.Anal(mbSet, 1000,7,1,"sample_description","Genus")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_2","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_2","png", width=NA)
mbSet<-RF.Anal(mbSet, 1000,7,0,"sample_description","Genus")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_3","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_3","png", width=NA)
mbSet<-RF.Anal(mbSet, 2000,7,0,"sample_description","Genus")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_4","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_4","png", width=NA)
mbSet<-RF.Anal(mbSet, 500,7,0,"sample_description","Genus")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_5","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_5","png", width=NA)
mbSet<-RF.Anal(mbSet, 500,10,0,"sample_description","Genus")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_6","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_6","png", width=NA)
mbSet<-RF.Anal(mbSet, 500,20,0,"sample_description","Genus")
mbSet<-PlotRF.Classify(mbSet, 15, "rf_cls_7","png", width=NA)
mbSet<-PlotRF.VIP(mbSet, 15, "rf_imp_7","png", width=NA)
mbSet<-Perform16FunAnot(mbSet, "Greengenes","qi_silva");
